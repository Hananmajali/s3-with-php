// photos-example-user

// bucket>> photos-example

// key >> AKIAIRKOZA5L4R24FS4Q

// secret key >> Gww2JW+g00MIxoX3g8uNUVFXsdX5GfcdT751aMP7

// user arn >> arn:aws:iam::458020214515:user/photos-example-user